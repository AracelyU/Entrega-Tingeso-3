package com.example.sia_fing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiaFingApplicationTests {

	@Test
	void contextLoads() {
	}

}
